export interface Movement {
    player: string,
    squareNumber: number,
}